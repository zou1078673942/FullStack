<template>
    <button
        @click="handleClick"
        class="el-button"
        :disabled="loading"
        :class="[
            type?'el-button--'+type:'',
            {
                'is-loading':loading,
                'is-round':round,
                'is-circle':circle
            }
        ]"
        >
        <i class="el-icon-loading" v-if="loading"></i>
        <i :class="icon" v-if="icon"></i>
        <!-- {{type}} - {{tit}} -->
        <slot></slot>
    </button>
</template>
<script>
    export default {
        data(){
            return {
                tit:'hello',
            }
        },
        props:{
            type:{
                type:String,
                default:'default'
            },
            round: Boolean,
            circle: Boolean,
            icon: {
                icon: String,
                default:''
            },
            loading: Boolean
        },
        created() {
            console.log(this.type,this.data)
        },
        methods:{
            handleClick(evt){
                console.log('--')
            }
        }
    }
</script>
<style>
</style>
