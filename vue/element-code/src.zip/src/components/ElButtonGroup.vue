<template>
    <div class="el-button-group">
        <slot/>
    </div>
</template>

<script>
    export default {
        name:'ElButtonGroup'
    }
</script>

<style scoped>

</style>