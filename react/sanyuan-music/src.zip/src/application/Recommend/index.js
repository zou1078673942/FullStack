import React, { useEffect, useState, memo } from 'react';
import { connect } from 'react-redux';
function Recommend(props) {
  const { recommendList,banners,enterLoading} = props
  console.log(recommendList,banners, enterLoading,'---------');
  return (
    <>
    Recommend
    </>
  )
}

const mapStateToProps = (state) => ({
  recommendList: state.recommend.recommendList,
  banners:state.recommend.banners,
  enterLoading:state.recommend.enterLoading
})
const mapDispatchToProps = (dispatch) => {
  return {

  }
}
export default connect(mapStateToProps, mapDispatchToProps)(memo(Recommend));