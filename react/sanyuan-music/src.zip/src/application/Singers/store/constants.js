  export const CHANGE_CATOGORY = 'home/singers/CHANGE_CATEGORY';
export const CHANGE_ALPHA = 'home/singers/CHANGE_ALPHA';
export const CHANGE_SINGER_LIST = 'home/singers/CHANGE_SINGER_LIST';
export const CHANGE_LIST_OFFSET = 'home/singers/CHANGE_LIST_OFFSET';
export const CHANGE_ENTER_LOADING = 'home/singers/ENTER_LOADING';
export const CHANGE_PULLUP_LOADING = 'home/singers/PULLUP_LOADING';
export const CHANGE_PULLDOWN_LOADING = 'home/singers/PULLDOWN_LOADING';