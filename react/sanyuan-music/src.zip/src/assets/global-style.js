export default {
  "font-size-ss": "10px",
  "font-size-s": "12px",
  "font-size-m": "14px",
  "font-size-l": "16px",
  "font-size-ll": "18px",
  "theme-color": "#d44439",
  "font-color-desc": "#2E3030",
  "border-color": "#e4e4e4",
  "font-color-light": "#f1f1f1",
}