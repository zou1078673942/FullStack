import React from "react";
// StatefullComponent  StatelessComponent

class Single extends React.Component {
  render() {
    return (
      <div>Single</div>
    )
  }
}

export default Single;