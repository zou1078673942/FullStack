import React from "react";
// StatefullComponent  StatelessComponent

class Search extends React.Component {
  render() {
    return (
      <div>Search</div>
    )
  }
}

export default Search;