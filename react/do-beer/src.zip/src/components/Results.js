import React from "react";
// StatefullComponent  StatelessComponent

class Results extends React.Component {
  render() {
    return (
      <div>Results</div>
    )
  }
}

export default Results;