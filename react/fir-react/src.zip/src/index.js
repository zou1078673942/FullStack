import React from 'react';
import ReactDOM from 'react-dom';
import Lesson from './Lesson';

ReactDOM.render(
  <React.StrictMode>
    <Lesson />
  </React.StrictMode>,
  document.getElementById('root')
);