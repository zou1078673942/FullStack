import PostCard from './PostCard'
import PostForm from './PostForm'

export { PostCard, PostForm }